library(tidyverse)
library(magrittr)
library(rlang)
library(scales)
library(fs)
library(purrr)
library(vctrs)
library(cowplot)
library(tidytext)

script_text <- read_lines("2003_Somethings_Gotta_Give.txt")

filmscript_tbl <- tibble(line_num = 1:length(script_text),
                         script_line = script_text) %>%
  mutate(

    ### Dialogue starts with 20 spaces
    is_dialogue_start = str_detect(script_line, '^\\s{20}'),

    ### Directions start with a tab followed by something other than a tab
    is_dialogue = str_detect(script_line, '^\\s{10}[^\\s]'),

    is_blank_line = (script_line == ''),

    is_direction = (is_dialogue_start == FALSE & is_dialogue == FALSE & is_blank_line == FALSE),

    is_new_segment = (is_dialogue_start == TRUE | is_direction == TRUE),

    group_incr = if_else((is_new_segment == TRUE), 1, 0),
    group_id = cumsum(group_incr),

    subject_group = if_else(is_dialogue_start == TRUE, script_line, NA_character_),
    subject_group = str_trim( subject_group, side = "left")
  ) %>%

  fill(subject_group, .direction = 'down')

### Create a new tbl without directions
dialogue_tbl <- filmscript_tbl %>%
  ### These are the columns that have important info
  select(is_dialogue_start, is_dialogue, script_line, group_id, subject_group) %>%

  # Only keep the rows that have info
  filter(is_dialogue == TRUE | is_dialogue_start == TRUE) %>%
  filter(!is.na(subject_group)) %>%

  ### Group lines from a single piece of dialogue
  group_by(group_id, subject_group) %>%

  ### Concatenate each line into a single string
  summarise(full_text = paste(script_line, collapse = ' '))

### Create new tbl to extract character and their respective lines

character_lines_tbl <- dialogue_tbl %>%
  mutate(
    character_name = str_replace(full_text, "\\s{20}([A-Z]+) .*", "\\1"),
    line_start     = str_replace(full_text, "\\s{20}[A-Z]+ ", ""),
    character_name = str_trim(character_name, side = "both"),
    dialogue       = str_trim(line_start, side = "both"),
    dialogue       = str_replace_all(dialogue, "\\s\\s+", " ")
  )


# Join Character Gender
gender_tbl <- read_csv("Somethings_Gotta_Give_Character_Gender.csv")

output_tbl <- character_lines_tbl %>%
  left_join(gender_tbl, by = "character_name") %>%
  select(character_name, gender, dialogue)


output_tbl %>% write_rds("../../parsed_rom_com_scripts/2003_somethings_gotta_give.rds")
