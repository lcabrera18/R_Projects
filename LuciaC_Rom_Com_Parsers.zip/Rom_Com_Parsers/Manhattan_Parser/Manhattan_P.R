library(tidyverse)
library(magrittr)
library(rlang)
library(scales)
library(fs)
library(purrr)
library(vctrs)
library(cowplot)
library(tidytext)

script_text <- read_lines("1979_Manhattan.txt") 

filmscript_tbl <- tibble(line_num = 1:length(script_text),
                         script_line = script_text) %>% 
  mutate(
    
    ###identify direction
    is_direction = str_detect(script_line, "^EXTERIOR") |
      str_detect(script_line, "^INTERIOR") |
      str_detect(script_line, "^CUT TO:"),
    
    #identify blank lines
    is_blank_line = (script_line == ''),
    
    #Almost everything else is dialogue
    dialogue_start = (is_direction == FALSE & is_blank_line == FALSE)
    
  )

#Create new tbl with dialogue and some directions
dialogue_tbl <- filmscript_tbl %>% 
  select(script_line, dialogue_start) %>% 
  filter(dialogue_start == TRUE)

#Identify dialogue start
dialogue_lines_tbl <- dialogue_tbl %>% 
  mutate(
    is_dialogue_start = str_detect(script_line, "^[A-Z]{2,}+ ")
    
  ) %>% 
  ### Filter dialogue starts
  select(script_line, is_dialogue_start) %>% 
  filter(is_dialogue_start == TRUE)


### Create new tbl to extract characters and their lines
character_lines_tbl <- dialogue_lines_tbl %>% 
  mutate(
    character_name = str_replace(script_line, "^([A-Z]+) .*", "\\1"),
    dialogue       = str_replace(script_line, "^[A-Z]+ ", "" ),
    character_name = str_trim(character_name, side = "both"),
    dialogue       = str_trim(dialogue, side = "both"),
    dialogue       = str_replace_all(dialogue, "\\s\\s+", " ")
  ) 

# Join Character Gender
gender_tbl <- read_csv("Manhattan_Character_Gender.csv")

output_tbl <- character_lines_tbl %>%
  left_join(gender_tbl, by = "character_name") %>%
  select(character_name, gender, dialogue)


output_tbl %>% write_rds("../../parsed_rom_com_scripts/1979_manhattan.rds")









 
  
