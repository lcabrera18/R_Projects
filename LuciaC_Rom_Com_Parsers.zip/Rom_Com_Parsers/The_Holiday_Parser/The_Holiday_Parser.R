library(tidyverse)
library(magrittr)
library(rlang)
library(scales)
library(fs)
library(purrr)
library(vctrs)
library(cowplot)
library(tidytext)
library(ngram)

script_text <- read_lines("2006_The_Holiday.txt")


filmscript_tbl <- tibble(line_num = 1:length(script_text),
                         script_line = script_text) %>%
  mutate(
    ### There are no direction in this script, only dialogue
    is_dialogue_start = str_detect(script_line, "^[A-Z]{2,}"),

    is_blank_line = (script_line == ''),

    ### Labelling each group with its own number
    group_incr = if_else((is_dialogue_start == TRUE), 1, 0),
    group_id = cumsum(group_incr),

    ### Dialogue starts with characters' names
    subject_group = if_else (is_dialogue_start == TRUE, script_line, NA_character_)
  ) %>%

  ### Fill down for every group/character line
  fill(subject_group, .direction = 'down')

lines_tbl <- filmscript_tbl %>%
  ###  Identify the columns that are relevant
  select(script_line, subject_group, group_id) %>%
  filter(!is.na(subject_group)) %>%
  group_by(group_id, subject_group) %>%
  summarise(full_text = paste(script_line,  collapse = '  '))


character_lines_tbl <-lines_tbl %>%
  mutate(
    character_name = str_replace(full_text, "^([A-Z]+) .*", "\\1"),
    dialogue_start = str_replace(full_text, "^[A-Z]+ ", ""),
    character_name = str_trim(character_name, side = "both"),
    dialogue       = str_trim(dialogue_start, side = "both"),
    dialogue       = str_replace_all(dialogue, "\\s\\s+", " "),
    dialogue       = str_replace_all(dialogue, "\\t+" , " ")
  )


# Join Character Gender
gender_tbl <- read_csv("The_Holiday_Character_Gender.csv")

output_tbl <- character_lines_tbl %>%
  left_join(gender_tbl, by = "character_name") %>%
  select(character_name, gender, dialogue)


output_tbl %>% write_rds("../../parsed_rom_com_scripts/2006_the_holiday.rds")



