library(tidyverse)
library(magrittr)
library(rlang)
library(scales)
library(fs)
library(purrr)
library(vctrs)
library(cowplot)
library(tidytext)

script_text <- read_lines("1998_The_Wedding_Singer.txt")

filmscript_tbl <- tibble(line_num = 1:length(script_text),
                         script_line = script_text) %>% 
  mutate(
    ### Dialogue starts with character's name in all caps followed by a colon
    is_dialogue_start = str_detect(script_line, "^[:alpha:]+\\:"),
    
    is_blank_line = (script_line == ''),
    
    ### Labelling each group with its own number
    group_incr = if_else((is_dialogue_start == TRUE), 1, 0),
    group_id = cumsum(group_incr),
    
    ### Dialogue starts with name of the character
    subject_group = if_else (is_dialogue_start == TRUE, script_line, NA_character_)
  ) %>% 
  
  ### Fill down for every group/character line
  fill(subject_group, .direction = 'down')

lines_tbl <- filmscript_tbl %>% 
  
  ### Identify columns that are relevant 
  select(script_line, subject_group, group_id) %>% 
  
  filter(!is.na(subject_group)) %>% 
  
  group_by(group_id, subject_group) %>% 
  summarise(full_text = paste(script_line, collapse = ' '))
  
### Create new tbl to extract character and their respective lines

character_lines_tbl <- lines_tbl %>% 
  mutate(
    character_name = str_replace(full_text, "^([:alpha:]+\\:) .*", "\\1"),
    dialogue = str_replace(full_text, "^[:alpha:]+\\: ", ""),
    character_name = str_trim(character_name, side = "both"),
    dialogue       = str_trim(dialogue, side = "both"),
    dialogue       = str_replace_all(dialogue, "\\s\\s+", " ")
  )

# Join Character Gender
gender_tbl <- read_csv("The_Wedding_Singer_Character_Gender.csv")

output_tbl <- character_lines_tbl %>%
  left_join(gender_tbl, by = "character_name") %>%
  select(character_name, gender, dialogue)


output_tbl %>% write_rds("../../parsed_rom_com_scripts/1998_the_wedding_singer.rds")


