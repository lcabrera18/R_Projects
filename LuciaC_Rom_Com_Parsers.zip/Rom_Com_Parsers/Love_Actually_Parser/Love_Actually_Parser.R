library(tidyverse)
library(magrittr)
library(rlang)
library(scales)
library(fs)
library(purrr)
library(vctrs)
library(cowplot)
library(tidytext)

script_text <- read_lines("2003_Love_Actually.txt")

filmscript_tbl <- tibble(line_num = 1:length(script_text),
                         script_line = script_text) %>% 
  mutate(
    # Dialogue starts with character's name followed by ':'
    is_dialogue_start = str_detect(script_line, "^[:alpha:]+\\:"), 
    
    is_blank_line = (script_line == ''),
    
    is_direction = (is_dialogue_start == FALSE & is_blank_line == FALSE)
  )
### Create a new tbl to focus on the columns with useful info. 

dialogue_tbl <- filmscript_tbl %>% 
  select(script_line, is_dialogue_start) %>% 
  filter(is_dialogue_start == TRUE) %>% 
  
  mutate(
    character_name = str_replace(script_line, "^([:alpha:]+\\:) .*", "\\1"),
    dialogue = str_replace(script_line, "^[:alpha:]+\\: ", "" ),
    dialogue       = str_replace_all(dialogue, "\\s\\s+", " ")
  )

# Join Character Gender
gender_tbl <- read_csv("Love_Actually_Character_Gender.csv")

output_tbl <- dialogue_tbl %>%
  left_join(gender_tbl, by = "character_name") %>%
  select(character_name, gender, dialogue)


output_tbl %>% write_rds("../../parsed_rom_com_scripts/2003_love_actually.rds")

